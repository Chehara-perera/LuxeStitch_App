create database luxestitch_db;

use luxestitch_db;

create table Users
(firstname varchar(100), lastname varchar(100), 
email varchar(100) primary key, telephone int, 
address varchar(100), password varchar(100));

select*from users;

create table feedback(text varchar(500) primary key, image_path varchar(10000));

select*from feedback;


create table  women_product(id int auto_increment primary key,
name varchar(255) not null,
image varchar(10000) not null,
price double not null);

insert women_product values (null, 'Heart Print Midi Dress','https://img.kwcdn.com/product/Fancyalgo/VirtualModelMatting/92daa21d3aa37eaa688f9c5f309639c3.jpg?imageView2/2/w/500/q/60/format/webp','36.22');

insert into women_product values (null, 'Aurora Fit & Flare Dress','https://images.bloomingdalesassets.com/is/image/BLM/products/5/optimized/11045145_fpx.tif?op_sharpen=1&wid=700','46.52');

insert into women_product values (null, 'Black & Peach Dress','https://assets.ajio.com/medias/sys_master/root/20231006/DIPX/651ffc02ddf7791519259404/-473Wx593H-463928195-black-MODEL.jpg','106.52');

insert into women_product values (null, 'Minty Halter Neck Dress','https://streetstylestalk.com/cdn/shop/products/1_27.jpg?v=1651738513','100.52');

insert into women_product values (null, 'Summer Pencil Dress','https://i.pinimg.com/originals/78/43/cf/7843cf1dfe1cd34aaecf9dc3817bc0f8.jpg','90.52');

delete from women_product where id=7;

Select * from women_product;

create table  men_product(id int auto_increment primary key,
name varchar(255) not null,
image varchar(10000) not null,
price double not null);

insert into men_product values (null,'Gray Long-Sleeve Shirt','https://www.crocodilesrilanka.com/cdn/shop/files/19353da6ia5-3.jpg?v=1699956533&width=1500',35.06);

insert into men_product values (null,'Blanket Shirt','https://www.outerknown.com/cdn/shop/products/1310023_Blanket_Shirt_MRT_3_768x.jpg?v=1673983767',35.06);

insert into men_product values (null,'Hawaiian Shirt','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQd1ny4J6Zh-uf_fVDBDiPH0pLw7OCp2jX2LQ3XgvERcA&s',18.25);

insert into men_product values (null,'Shirt Jacket','https://n.nordstrommedia.com/id/sr3/e19b50a8-0561-4af3-a451-faaa8996b1d5.jpeg?h=365&w=240&dpr=2',25.67);

insert into men_product values (null,'Grey Linen Pnats','https://cdn.linenclub.com/media/catalog/product/cache/5399faaab5f4f7a53013d830013bdee7/l/c/lcmtc101pd00592-e4_0_1.jpg',25.67);


Select * from men_product;

create table  kid_product(id int auto_increment primary key,
name varchar(255) not null,
image varchar(10000) not null,
price double not null);

insert into kid_product values (null, 'Wetsuit Tug Boats','https://live-m2-uk.splashabout.com/media/catalog/product/cache/c5061de8e88d776f91f5711aaa0d89a1/h/n/hnwtb_1200x1200.jpg','8.7');

insert into kid_product values (null, 'Rainbow Dress','https://www.kidrepublic.co.nz/user/images/68411.jpg','10.95');

insert into kid_product values (null, 'Denim Doughnut Jacket','https://m.media-amazon.com/images/I/71-qxy+7tUL._AC_UY1000_.jpg','5.95');

insert into kid_product values (null, 'Denim Jeans','https://www.dhresource.com/webp/m/0x0/f2/albu/g18/M00/A1/F5/rBVapGBDS62AIbncAAh2ODhk0MI773.jpg','5.95');

insert into kid_product values (null, 'Flower Splash Dress','https://www.burrowandbe.co.nz/assets/alt_2/SGBDFS.jpg?20220221201514','5.95');





