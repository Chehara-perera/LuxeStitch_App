const express = require('express');
const mysql = require('mysql');
const app = express();

app.use(express.json());

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'luxestitch_db'
});

connection.connect(err => {
    if (err) throw err;
    console.log('Connected to MySQL database');
});



// Endpoint to get all distinct categories
app.get('/api/categories', (req, res) => {
    const sql = 'SELECT DISTINCT category FROM product';
    connection.query(sql, (error, results) => {
        if (error) {
            return res.status(500).json({ error: 'Database error' });
        }
        // Extract categories from the results
        const categories = results.map(row => row.category);
        res.json(categories);
    });
});




// Endpoint to get women products
app.get('/api/women_products', (req, res) => {
    const sql = 'SELECT id,name,image,price FROM women_product';
    connection.query(sql, (error, results) => {
      if (error) {
        console.error('Database error: ' + error.message);
        return res.status(500).json({ error: 'Database error' });
      }
      res.json(results);
    });
  });

  // Endpoint to get men products
app.get('/api/men_products', (req, res) => {
    const sql = 'SELECT id,name,image,price FROM men_product';
    connection.query(sql, (error, results) => {
      if (error) {
        console.error('Database error: ' + error.message);
        return res.status(500).json({ error: 'Database error' });
      }
      res.json(results);
    });
  });

    // Endpoint to get kids products
app.get('/api/kid_products', (req, res) => {
    const sql = 'SELECT id,name,image,price FROM kid_product';
    connection.query(sql, (error, results) => {
      if (error) {
        console.error('Database error: ' + error.message);
        return res.status(500).json({ error: 'Database error' });
      }
      res.json(results);
    });
  });



// Register user
app.post('/api/users/register', (req, res) => {
    const { firstname, lastname, email, telephone, address, password } = req.body;
    const query = 'INSERT INTO users (firstname, lastname, email, telephone, address, password) VALUES (?, ?, ?, ?, ?, ?)';
    connection.query(query, [firstname, lastname, email, telephone, address, password], (err, result) => {
        if (err) {
            res.status(500).json({ message: 'Error registering new user', error: err });
            return;
        }
        res.status(200).json({ message: 'User registered successfully', userId: result.email });
    });
});



// Authenticate user
app.post('/api/users/login', (req, res) => {
    const { Email, password } = req.body;
    const query = 'SELECT * FROM users WHERE Email = ? AND password = ?';
    connection.query(query, [Email, password], (err, results) => {
        if (err) {
            res.status(500).json({ message: 'Error retrieving user details', error: err });
            return;
        }
        if (results.length > 0) {
            res.status(200).json({ message: 'Login successful', userId: results[0].id });
        } else {
            res.status(401).json({ message: 'Invalid credentials' });
        }
    });
});


//get user
app.get('/api/users/:email', (req, res) => {
    const email = req.params.email;
    const query = `SELECT * FROM users WHERE email = '${email}'`;

    connection.query(query, (error, results, fields) => {
        if (error) {
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            if (results.length === 0) {
                res.status(404).json({ error: 'User not found' });
            } else {
                res.json(results[0]);
            }
        }
    });
});


app.post('/api/cart', (req, res) => {
    const { userId, items } = req.body;
    // Start a transaction to ensure all inserts are treated as a single operation
    connection.beginTransaction((transactionError) => {
        if (transactionError) {
            return res.status(500).json({ message: 'Transaction start error', error: transactionError });
        }
        const queries = items.map(item => {
            return new Promise((resolve, reject) => {
                const query = 'REPLACE INTO cart (userId, productId, quantity, imageUrl) VALUES (?, ?, ?, ?)';
                connection.query(query, [userId, item.product.id, item.quantity, item.product.image], (err, result) => {
                    if (err) reject(err);
                    resolve(result);
                });
            });
        });
        Promise.all(queries)
            .then(() => {
                connection.commit(commitError => {
                    if (commitError) {
                        return connection.rollback(() => {
                            res.status(500).json({ message: 'Transaction commit error', error: commitError });
                        });
                    }
                    res.status(201).json({ message: 'Cart saved successfully' });
                });
            })
            .catch(queryError => {
                connection.rollback(() => {
                    res.status(500).json({ message: 'Transaction error', error: queryError });
                });
            });
    });
});

/*Multer storage configuration
 const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/'); // Destination folder for uploaded images
     },
     filename: function (req, file, cb) {
         cb(null, file.originalname); // Keep the original filename
     }
});

const upload = multer({ storage: storage });

 Connect to MySQL database
 connection.connect((err) => {
    if (err) {
        console.error('Error connecting to database:', err);
         return;
    }
   console.log('Connected to MySQL database');
 });

 Handle POST request for feedback submission with image upload
 app.post('/api/feedback', upload.single('image'), (req, res) => {
     const { feedbackText } = req.body;
     const imageFilePath = req.file ? req.file.path : null; // Get the file path of the uploaded image

     // Insert feedback and image details into the database
     const query = 'INSERT INTO feedback (text, image_path) VALUES (?, ?)';
     connection.query(query, [feedbackText, imageFilePath], (error, results) => {
         if (error) {
          console.error('Error inserting feedback into database:', error);
           res.status(500).json({ error: 'Failed to submit feedback' });
             return;
         }
         res.status(200).json({ message: 'Feedback submitted successfully' });
     });
 });

 Serve uploaded images statically
 app.use('/uploads', express.static(path.join(__dirname, 'uploads')));*/


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

