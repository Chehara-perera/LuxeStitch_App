//
//  CartModel.swift
//  LuxeStitch
//
//  Created by Chehara Perera on 2024-03-29.
//

import Foundation
import SwiftUI

struct CartModel: Identifiable {
    let id = UUID()
    let name: String
    var quantity: Int
    let imageName: String
}
