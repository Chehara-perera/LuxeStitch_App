//
//  FeedbackModel.swift
//  LuxeStitch
//
//  Created by Chehara Perera on 2024-03-29.
//

import Foundation
struct Feedback {
    var feedbackText: String
    var imageData: Data?
}
