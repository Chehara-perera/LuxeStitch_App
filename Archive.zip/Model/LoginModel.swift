//
//  LoginModel.swift
//  LuxeStitch
//
//  Created by Chehara Perera on 2024-03-28.
//
struct LoginModel {
    var username: String = ""
    var password: String = ""
}

