//
//  ProductModel.swift
//  LuxeStitch
//
//  Created by Chehara Perera on 2024-03-29.
//
import Foundation

struct ProductModel: Codable, Identifiable {
    let id: Int
    let name: String
    let price: Int
}
