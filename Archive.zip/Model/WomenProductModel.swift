//
//  WomenProductModel.swift
//  LuxeStitch
//
//  Created by Chehara Perera on 2024-03-28.
//
struct WomenProduct: Codable, Identifiable {
    let id: Int
    let name: String
    let image: String
    let description: String
    let price: Int
    let quantity: Int
}

