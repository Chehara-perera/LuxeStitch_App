//
//  LuxeStitchApp.swift
//  LuxeStitch
//
//  Created by Chehara Perera on 2024-03-17.
//

import SwiftUI

@main
struct LuxeStitchApp: App {
    var body: some Scene {
        WindowGroup {
            HomeView()
        }
    }
}
