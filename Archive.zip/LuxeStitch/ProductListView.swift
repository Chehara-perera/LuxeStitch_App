//
//  ProductListView.swift
//  LuxeStitch
//
//  Created by Chehara Perera on 2024-03-19.
//

import SwiftUI

struct ProductListView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ProductListView()
}
