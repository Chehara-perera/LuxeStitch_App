//
//  WomenProductView.swift
//  LuxeStitch
//
//  Created by Chehara Perera on 2024-03-28.
//
import SwiftUI

struct WomenProductView: View {
    @ObservedObject var viewModel = WomenProductViewModel()
    
    var body: some View {
        
        Text("Women")
        
        List(viewModel.products) { product in
            VStack(alignment: .leading) {
                Text(product.name)
                    .font(.headline)
                Text(product.description)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                Text("$\(product.price)")
                    .font(.headline)
                    .foregroundColor(.blue)
            }
        }
        .onAppear {
            viewModel.fetchData()
        }
    }
}

struct WomenProductView_Previews: PreviewProvider {
    static var previews: some View {
        WomenProductView()
    }
}
