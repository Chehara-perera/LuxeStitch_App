//
//  DetailView.swift
//  LuxeStitch
//
//  Created by Chehara Perera on 2024-03-29.
//
import SwiftUI

struct DetailView: View {
    @ObservedObject var viewModel: DetailViewModel
    
    var body: some View {
        VStack {
            Spacer().frame(height: 30)
            
            Image(viewModel.product.imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: 300)
            
            Text(viewModel.product.name)
                .font(.title)
                .padding()
            
            Text(viewModel.product.description)
                .padding()
            
            VStack(alignment: .leading) {
                HStack {
                    Text("Sizes:")
                    Picker("Select Size", selection: $viewModel.selectedSizeIndex) {
                        ForEach(0..<viewModel.product.sizes.count, id: \.self) { index in
                            Text(viewModel.product.sizes[index])
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .frame(width: 200)
                }
                
                HStack {
                    Text("Quantity:")
                    Stepper(value: $viewModel.selectedQuantity, in: 1...10) {
                        Text("\(viewModel.selectedQuantity)")
                    }
                }
                .padding(.top)
            }
            .padding()
            
            Button(action: {
                viewModel.addToCart()
            }) {
                Text("Add to Cart")
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.green)
                    .cornerRadius(8)
            }
            .padding()
        }
        .navigationBarTitle("", displayMode: .inline)
        .navigationBarItems(leading: backButton)
    }
    
    private var backButton: some View {
        NavigationLink(destination: WomenProductView()) {
            HStack {
                Image(systemName: "chevron.left")
                Text("Back")
            }
        }
    }
}

// Preview
struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            DetailView(viewModel: DetailViewModel(product: DetailViewModel.sampleProduct))
        }
    }
}

