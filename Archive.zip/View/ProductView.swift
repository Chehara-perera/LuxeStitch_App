//
//  ProductView.swift
//  LuxeStitch
//
//  Created by Chehara Perera on 2024-03-29.
//
import SwiftUI

struct ProductView: View {
    @ObservedObject var viewModel = ProductViewModel()
    
    var body: some View {
        NavigationView {
            List(viewModel.products) { product in
                VStack(alignment: .leading) {
                    Text(product.name)
                    Text("$\(product.price)")
                        .foregroundColor(.gray)
                }
            }
            .navigationBarTitle("Products")
            .onAppear {
                viewModel.fetchData()
            }
        }
    }
}

struct ProductView_Previews: PreviewProvider {
    static var previews: some View {
        ProductView()
    }
}
