//
//  BabyProductView.swift
//  LuxeStitch
//
//  Created by Chehara Perera on 2024-03-28.
//

/*import SwiftUI

// Product model
struct Product: Identifiable {
    let id: Int
    let name: String
    let image: String
    let description: String
    let price: Double
}

// Mock products data
let mockProducts: [Product] = [
    Product(id: 1, name: "Product 1", image: "Image1", description: "Description of Product 1", price: 10.99),
    Product(id: 2, name: "Product 2", image: "Image2", description: "Description of Product 2", price: 20.99),
    // Add more products as needed
]

struct Product_ListView: View {
    let productsPerPage = 10 // Number of products per page
    @State private var currentPage = 1
    
    var paginatedProducts: [Product] {
        let startIndex = (currentPage - 1) * productsPerPage
        let endIndex = min(startIndex + productsPerPage, mockProducts.count)
        return Array(mockProducts[startIndex..<endIndex])
    }
    
    var body: some View {
        
        
        
        VStack {
                  
            
                Text("Baby Collection").font(.title)
                // Product List
                List(paginatedProducts) { product in
                    ProductRowView(product: product)
                }
            
        
    
            // Pagination Buttons
            HStack {
                Button(action: {
                    if self.currentPage > 1 {
                        self.currentPage -= 1
                    }
                }) {
                    Text("Previous")
                }
                
                Spacer()
                
                Text("Page \(currentPage)")
                
                Spacer()
                
                Button(action: {
                    let maxPage = (mockProducts.count + self.productsPerPage - 1) / self.productsPerPage
                    if self.currentPage < maxPage {
                        self.currentPage += 1
                    }
                }) {
                    Text("Next")
                }
            }.padding()
        }
    }
}

struct ProductRowView: View {
    let product: Product
    
    var body: some View {
        HStack {
            Image(product.image)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100, height: 100)
            
            VStack(alignment: .leading) {
                Text(product.name)
                    .font(.headline)
                Text(product.description)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                Text("$\(product.price)")
                    .font(.headline)
                    .foregroundColor(.blue)
            }
            
            Spacer()
            
            Button(action: {
                // Add to cart action
            }) {
                Text("Add to Cart")
                    .foregroundColor(.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(Color.blue)
                    .cornerRadius(5)
            }
        }.padding()
    }
}

struct ProductView: View {
    var body: some View {
        Product_ListView()
    }
}

struct ProductView_Previews: PreviewProvider {
    static var previews: some View {
        ProductView()
    }
}*/
