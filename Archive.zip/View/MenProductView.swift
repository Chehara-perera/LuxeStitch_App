//
//  MenProductView.swift
//  LuxeStitch
//
//  Created by Chehara Perera on 2024-03-28.
//

/*import SwiftUI

// Product model
struct menProduct: Identifiable {
    let id: Int
    let name: String
    let image: String
    let description: String
    let price: Double
}

// Mock products data
let mockMenProducts: [menProduct] = [
    menProduct(id: 1, name: "Product 1", image: "Image1", description: "Description of Product 1", price: 10.99),
    menProduct(id: 2, name: "Product 2", image: "Image2", description: "Description of Product 2", price: 20.99),
    // Add more products as needed
]

struct menProduct_ListView: View {
    let menproductsPerPage = 10 // Number of products per page
    @State private var currentPage = 1
    
    var paginatedProducts: [Product] {
        let startIndex = (currentPage - 1) * menproductsPerPage
        let endIndex = min(startIndex + menproductsPerPage, mockMenProducts.count)
        return Array(mockProducts[startIndex..<endIndex])
    }
    
    var body: some View {
        
        
        
        VStack {
                  
            
                Text("Men's Collection").font(.title)
                // Product List
                List(paginatedProducts) { product in
                    ProductRowView(product: product)
                }
            
        
    
            // Pagination Buttons
            HStack {
                Button(action: {
                    if self.currentPage > 1 {
                        self.currentPage -= 1
                    }
                }) {
                    Text("Previous")
                }
                
                Spacer()
                
                Text("Page \(currentPage)")
                
                Spacer()
                
                Button(action: {
                    let maxPage = (mockMenProducts.count + self.menproductsPerPage - 1) / self.menproductsPerPage
                    if self.currentPage < maxPage {
                        self.currentPage += 1
                    }
                }) {
                    Text("Next")
                }
            }.padding()
        }
    }
}

struct menProductRowView: View {
    let product: Product
    
    var body: some View {
        HStack {
            Image(product.image)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100, height: 100)
            
            VStack(alignment: .leading) {
                Text(product.name)
                    .font(.headline)
                Text(product.description)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                Text("$\(product.price)")
                    .font(.headline)
                    .foregroundColor(.blue)
            }
            
            Spacer()
            
            Button(action: {
                // Add to cart action
            }) {
                Text("Add to Cart")
                    .foregroundColor(.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(Color.blue)
                    .cornerRadius(5)
            }
        }.padding()
    }
}

struct menProductView: View {
    var body: some View {
        menProduct_ListView()
    }
}

struct menProductView_Previews: PreviewProvider {
    static var previews: some View {
        menProductView()
    }
}*/
