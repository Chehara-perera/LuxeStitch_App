//
//  DetailViewModel.swift
//  LuxeStitch
//
//  Created by Chehara Perera on 2024-03-29.
//
import SwiftUI

// DetailViewModel managing product details
class DetailViewModel: ObservableObject {
    @Published var product: DetailModel
    @Published var selectedQuantity: Int = 1
    @Published var selectedSizeIndex: Int = 0
    
    init(product: DetailModel) {
        self.product = product
    }
    
    func addToCart() {
        // Implement add to cart functionality here
    }
    
    // Sample product for preview
    static let sampleProduct = DetailModel(id: UUID(), name: "Floral Dress", description: "Material: polyester fabric", imageName: "cart_item3", quantity: 1, sizes: ["Small", "Medium", "Large"])
}
