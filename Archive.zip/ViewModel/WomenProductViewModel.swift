//
//  WomenProductViewModel.swift
//  LuxeStitch
//
//  Created by Chehara Perera on 2024-03-28.
//
import Foundation

class WomenProductViewModel: ObservableObject {
    @Published var products: [WomenProduct] = []

    func fetchData() {
        guard let url = URL(string: "http://localhost:3000/api/women_fashion/retrieve") else { return }
        
        URLSession.shared.dataTask(with: url) { data, _, error in
            guard let data = data, error == nil else {
                print("Failed to fetch data: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
            do {
                let decodedData = try JSONDecoder().decode([WomenProduct].self, from: data)
                DispatchQueue.main.async {
                    self.products = decodedData
                }
            } catch {
                print("Failed to decode JSON: \(error.localizedDescription)")
            }
        }.resume()
    }
}

