//
//  ProductViewModel.swift
//  LuxeStitch
//
//  Created by Chehara Perera on 2024-03-29.
//
import Foundation

class ProductViewModel: ObservableObject {
    @Published var products: [ProductModel] = []
    
    func fetchData() {
        guard let url = URL(string: "http://localhost:3000/api/products") else {
            print("Invalid URL")
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                print("Error: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
            do {
                let decodedData = try JSONDecoder().decode([ProductModel].self, from: data)
                DispatchQueue.main.async {
                    self.products = decodedData
                }
            } catch {
                print("Error decoding JSON: \(error.localizedDescription)")
            }
        }.resume()
    }
}
